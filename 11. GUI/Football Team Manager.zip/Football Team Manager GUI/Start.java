import java.lang.*;
import Entity.*;
import GUI.*;

public class Start{
	public static void main(String[] args){
		TeamManagerPage tm = new TeamManagerPage();
	}
}